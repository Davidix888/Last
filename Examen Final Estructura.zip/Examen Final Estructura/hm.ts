class Task {
    private name: string;
    private priority: number;
    private descripcion: string;

    constructor(name: string, priority: number, descripcion: string) {
        this.name = name;
        this.priority = priority;
        this.descripcion = descripcion;
    }

    public getNameTask(): string {
        return this.name;
    }

    public getPriorityTask(): number {
        return this.priority;
    }

    public getDescriptionTask(): string {
        return this.descripcion;
    }

    public setPriority(priority: number): void {
        this.priority = priority;
    }
}

class MinHeapTask {
    public heap: Task[];
    private n: number;

    constructor(size: number) {
        this.heap = new Array(size + 1);
        this.n = 0;
    }

    public getQuantity(): number {
        return this.n;
    }

    public insert(value: Task): void {
        if (this.n === this.heap.length - 1) {
            this.resize(2 * this.heap.length);
        }
        this.n++;
        this.heap[this.n] = value;
        this.swim(this.n);
    }

    public getMin(): Task {
        let min = this.heap[1];
        this.heap[1] = this.heap[this.n];
        this.n--;
        this.swim(1);
        return min;
    }

    private swim(i: number): void {
        let parent = Math.floor(i / 2);
        let child = 2 * i;

        if (i > 1 && this.heap[parent]!.getPriorityTask() > this.heap[i]!.getPriorityTask()) {
            [this.heap[parent], this.heap[i]] = [this.heap[i], this.heap[parent]];
            this.swim(parent);
        } else if (child <= this.n) {
            let smallest = child;
            if (child + 1 <= this.n && this.heap[child]!.getPriorityTask() > this.heap[child + 1]!.getPriorityTask()) {
                smallest = child + 1;
            }
            if (this.heap[i]!.getPriorityTask() > this.heap[smallest]!.getPriorityTask()) {
                [this.heap[i], this.heap[smallest]] = [this.heap[smallest], this.heap[i]];
                this.swim(smallest);
            }
        }
    }

    public actualizar(taskName: string, newPriority: number): void {
        for (let i = 1; i <= this.n; i++) {
            if (this.heap[i].getNameTask() === taskName) {
                this.heap[i].setPriority(newPriority);
                this.swim(i); 
                return;
            }
        }
        console.log(`Tarea "${taskName}" no encontrada`);
    }

    private resize(newSize: number): void {
        let newHeap: Task[] = new Array(newSize);
        for (let i = 1; i <= this.n; i++) {
            newHeap[i] = this.heap[i];
        }
        this.heap = newHeap;
    }

    public mostrartareas(): void {
        for (let i = 1; i <= this.n; i++) {
            const task = this.heap[i];
            console.log(task.getNameTask() + " - Prioridad: " + task.getPriorityTask());
        }
    }

    public buscar(priority: number): Task[] {
        let buscar: Task[] = new Array(this.n); 
        let contador = 0; 
    
        for (let i = 1; i <= this.n; i++) {
            if (this.heap[i].getPriorityTask() === priority) {
                buscar[contador] = this.heap[i];
                contador++;
            }
        }
    
        let result: Task[] = new Array(contador);
        for (let j = 0; j < contador; j++) {
            result[j] = buscar[j];
        }
    
        return result;
    }
    
    
}

let task1: Task = new Task("Calificar Laboratorio 1", 1, "Prioridad 1");
let task2: Task = new Task("Calificar Laboratorio 2", 4, "Prioridad 4");
let task4: Task = new Task("Preparar la siguiente clase", 2, "Prioridad 2");

let minHeap = new MinHeapTask(6);

minHeap.insert(task1);
minHeap.insert(task2);
minHeap.insert(task4);

console.log("Tareas:");
minHeap.mostrartareas();
console.log("");

minHeap.actualizar("Calificar Laboratorio 2", 6);

console.log("Tareas con prioriad actualizada:");
minHeap.mostrartareas();

console.log("");
let minTask = minHeap.getMin();
console.log("Tarea eliminada:", minTask.getNameTask());

console.log("");
console.log("Tareas restantes:");
minHeap.mostrartareas();

console.log("");
console.log("Buscar dato por prioridad")

let buscar1 = minHeap.buscar(6);
for(let i = 0; i < buscar1.length; i++){
    console.log(buscar1[i].getNameTask() + " - " + buscar1[i].getDescriptionTask());
}