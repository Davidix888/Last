class Product {
    private codigo: string;
    private nombre: string;
    private precio: number;

    constructor(codigo: string, nombre: string, precio: number) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.precio = precio;
    }

    public getCodigo(): string {
        return this.codigo;
    }

    public setCodigo(nuevoCodigo: string): void {
        this.codigo = nuevoCodigo;
    }

    public getNombre(): string {
        return this.nombre;
    }

    public setNombre(nuevoNombre: string): void {
        this.nombre = nuevoNombre;
    }

    public getPrecio(): number {
        return this.precio;
    }

    public setPrecio(nuevoPrecio: number): void {
        this.precio = nuevoPrecio;
    }
}

class AVLNode {
    public altura: number;
    public izquierdo: AVLNode | null;
    public derecho: AVLNode | null;

    constructor(public producto: Product) {
        this.altura = 1;
        this.izquierdo = null;
        this.derecho = null;
    }
}

class AVLTree {
    private raiz: AVLNode | null = null;

    private getAltura(nodo: AVLNode | null): number {
        return nodo ? nodo.altura : 0;
    }

    private getBalance(nodo: AVLNode | null): number {
        return nodo ? this.getAltura(nodo.izquierdo) - this.getAltura(nodo.derecho) : 0;
    }

    private rotarDerecha(y: AVLNode): AVLNode {
        const x = y.izquierdo!;
        const T2 = x.derecho;

        x.derecho = y;
        y.izquierdo = T2;

        y.altura = 1 + Math.max(this.getAltura(y.izquierdo), this.getAltura(y.derecho));
        x.altura = 1 + Math.max(this.getAltura(x.izquierdo), this.getAltura(x.derecho));

        return x;
    }

    private rotarIzquierda(x: AVLNode): AVLNode {
        const y = x.derecho!;
        const T2 = y.izquierdo;

        y.izquierdo = x;
        x.derecho = T2;

        x.altura = 1 + Math.max(this.getAltura(x.izquierdo), this.getAltura(x.derecho));
        y.altura = 1 + Math.max(this.getAltura(y.izquierdo), this.getAltura(y.derecho));

        return y;
    }

    public insertar(producto: Product): void {
        this.raiz = this.insertarNodo(this.raiz, producto);
    }

    private insertarNodo(nodo: AVLNode | null, producto: Product): AVLNode {
        if (!nodo) return new AVLNode(producto);

        if (producto.getPrecio() < nodo.producto.getPrecio()) {
            nodo.izquierdo = this.insertarNodo(nodo.izquierdo, producto);
        } else if (producto.getPrecio() > nodo.producto.getPrecio()) {
            nodo.derecho = this.insertarNodo(nodo.derecho, producto);
        } else {
            throw new Error("No se permiten productos con precios duplicados.");
        }

        nodo.altura = 1 + Math.max(this.getAltura(nodo.izquierdo), this.getAltura(nodo.derecho));
        const balance = this.getBalance(nodo);

        if (balance > 1 && producto.getPrecio() < nodo.izquierdo!.producto.getPrecio()) {
            return this.rotarDerecha(nodo);
        }
        if (balance < -1 && producto.getPrecio() > nodo.derecho!.producto.getPrecio()) {
            return this.rotarIzquierda(nodo);
        }
        if (balance > 1 && producto.getPrecio() > nodo.izquierdo!.producto.getPrecio()) {
            nodo.izquierdo = this.rotarIzquierda(nodo.izquierdo!);
            return this.rotarDerecha(nodo);
        }
        if (balance < -1 && producto.getPrecio() < nodo.derecho!.producto.getPrecio()) {
            nodo.derecho = this.rotarDerecha(nodo.derecho!);
            return this.rotarIzquierda(nodo);
        }

        return nodo;
    }

    public eliminar(precio: number): void {
        this.raiz = this.eliminarNodo(this.raiz, precio);
    }

    private eliminarNodo(nodo: AVLNode | null, precio: number): AVLNode | null {
        if (!nodo) return null;

        if (precio < nodo.producto.getPrecio()) {
            nodo.izquierdo = this.eliminarNodo(nodo.izquierdo, precio);
        } else if (precio > nodo.producto.getPrecio()) {
            nodo.derecho = this.eliminarNodo(nodo.derecho, precio);
        } else {
            if (!nodo.izquierdo || !nodo.derecho) {
                nodo = nodo.izquierdo || nodo.derecho;
            } else {
                const sucesor = this.obtenerMinimo(nodo.derecho);
                nodo.producto = sucesor!.producto;
                nodo.derecho = this.eliminarNodo(nodo.derecho, sucesor!.producto.getPrecio());
            }
        }

        if (!nodo) return null;

        nodo.altura = 1 + Math.max(this.getAltura(nodo.izquierdo), this.getAltura(nodo.derecho));
        const balance = this.getBalance(nodo);

        if (balance > 1 && this.getBalance(nodo.izquierdo) >= 0) {
            return this.rotarDerecha(nodo);
        }
        if (balance > 1 && this.getBalance(nodo.izquierdo) < 0) {
            nodo.izquierdo = this.rotarIzquierda(nodo.izquierdo!);
            return this.rotarDerecha(nodo);
        }
        if (balance < -1 && this.getBalance(nodo.derecho) <= 0) {
            return this.rotarIzquierda(nodo);
        }
        if (balance < -1 && this.getBalance(nodo.derecho) > 0) {
            nodo.derecho = this.rotarDerecha(nodo.derecho!);
            return this.rotarIzquierda(nodo);
        }

        return nodo;
    }

    private obtenerMinimo(nodo: AVLNode | null): AVLNode | null {
        while (nodo?.izquierdo) {
            nodo = nodo.izquierdo;
        }
        return nodo;
    }

    private obtenerMaximo(nodo: AVLNode | null): AVLNode | null {
        while (nodo?.derecho) {
            nodo = nodo.derecho;
        }
        return nodo;
    }

    public buscarMinimo(): Product | null {
        const nodo = this.obtenerMinimo(this.raiz);
        return nodo ? nodo.producto : null;
    }

    public buscarMaximo(): Product | null {
        const nodo = this.obtenerMaximo(this.raiz);
        return nodo ? nodo.producto : null;
    }

    public buscarEnRango(precioMin: number, precioMax: number): Product[] {
        const resultado: Product[] = [];
        this.buscarEnRangoRec(this.raiz, precioMin, precioMax, resultado);
        return resultado;
    }

    private buscarEnRangoRec(nodo: AVLNode | null, precioMin: number, precioMax: number, resultado: Product[]): void {
        if (!nodo) return;

        if (nodo.producto.getPrecio() >= precioMin && nodo.producto.getPrecio() <= precioMax) {
            resultado.push(nodo.producto);
        }

        if (precioMin < nodo.producto.getPrecio()) {
            this.buscarEnRangoRec(nodo.izquierdo, precioMin, precioMax, resultado);
        }

        if (precioMax > nodo.producto.getPrecio()) {
            this.buscarEnRangoRec(nodo.derecho, precioMin, precioMax, resultado);
        }
    }

    public imprimir(): void {
        this.imprimirNodo(this.raiz);
    }

    private imprimirNodo(nodo: AVLNode | null): void {
        if (nodo) {
            this.imprimirNodo(nodo.izquierdo);
            console.log(`Código: ${nodo.producto.getCodigo()}, Nombre: ${nodo.producto.getNombre()}, Precio: ${nodo.producto.getPrecio()}`);
            this.imprimirNodo(nodo.derecho);
        }
    }
}

// Ejemplo de uso
const tienda = new AVLTree();
tienda.insertar(new Product("P1", "Producto A", 50));
tienda.insertar(new Product("P2", "Producto B", 20));
tienda.insertar(new Product("P3", "Producto C", 70));
tienda.insertar(new Product("P4", "Producto D", 60));
console.log("\nProductos:");
tienda.imprimir();
console.log("\nProducto eliminado");
tienda.eliminar(50);
console.log("\nProductos:");
tienda.imprimir();

const minimo = tienda.buscarMinimo();
console.log(`\nProducto con el precio más bajo: ${minimo?.getNombre()}`);

const maximo = tienda.buscarMaximo();
console.log(`\nProducto con el precio más alto: ${maximo?.getNombre()}`);

const enRango = tienda.buscarEnRango(30, 60);
console.log("\nProductos en rango [30, 60]:");
enRango.forEach((p) => console.log(`${p.getNombre()} - Precio: ${p.getPrecio()}`));
