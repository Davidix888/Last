class Student {
    private name: string;
    private carnet: string;
    private carrer: string;

    constructor(name: string, carnet: string, carrer: string) {
        this.name = name;
        this.carnet = carnet;
        this.carrer = carrer;
    }

    public getName(): string {
        return this.name;
    }

    public getCarnet(): string {
        return this.carnet;
    }

    public getCarrer(): string {
        return this.carrer;
    }

    public toString(): string {
        return "Carnet: " + this.carnet + " Nombre: " + this.name + " Carrera: " + this.carrer;
    }
}

class Nodo {
    student: Student;
    next: Nodo | null;

    constructor(student: Student) {
        this.student = student;
        this.next = null;
    }
}

class ListaEnlazada {
    head: Nodo | null;

    constructor() {
        this.head = null;
    }

    public insert(student: Student): void {
        const newnode = new Nodo(student);
        if (this.head === null) {
            this.head = newnode;
        } else {
            let current = this.head;
            while (current.next !== null) {
                current = current.next;
            }
            current.next = newnode;
        }
    }

    public searchAll(carnet: string): Student[] {
        let current = this.head;
        const results: Student[] = [];
        while (current !== null) {
            if (current.student.getCarnet() === carnet) {
                results.push(current.student);
            }
            current = current.next;
        }
        return results;
    }

    public delete(carnet: string): boolean {
        if (this.head === null) return false;

        if (this.head.student.getCarnet() === carnet) {
            this.head = this.head.next;
            return true;
        }

        let current = this.head;
        while (current.next !== null) {
            if (current.next.student.getCarnet() === carnet) {
                current.next = current.next.next;
                return true;
            }
            current = current.next;
        }

        return false;
    }

    public print(): string {
        const students: string[] = [];
        let current = this.head;
        while (current !== null) {
            students.push(current.student.toString());
            current = current.next;
        }
        return students.join(", ");
    }
}

class HashTable {
    private size: number;
    private data: (ListaEnlazada | null)[];

    constructor() {
        this.size = 10;
        this.data = new Array(this.size).fill(null);
    }

    private hash(carnet: string): number {
        let numero = 0;
        const digitos = '0123456789';
        for (let i = 0; i < carnet.length; i++) {
            let esDigito = false;
            let valorDigito = 0;
            for (let j = 0; j < digitos.length; j++) {
                if (carnet[i] === digitos[j]) {
                    esDigito = true;
                    valorDigito = j;
                    break;
                }
            }
            if (esDigito) {
                numero = numero * 10 + valorDigito;
            }
        }
        return (numero * 31 + 7) % this.size;
    }

    public insert(student: Student): void {
        const index: number = this.hash(student.getCarnet());
        if (this.data[index] === null) {
            this.data[index] = new ListaEnlazada();
        }
        this.data[index]!.insert(student);
    }

    public search(carnet: string): void {
        const index: number = this.hash(carnet);
        if (this.data[index] !== null) {
            const students = this.data[index]!.searchAll(carnet);
            if (students.length > 0) {
                for (let i = 0; i < students.length; i++) {
                    console.log("Estudiante encontrado:", students[i].toString());
                }
            } else {
                console.log("No se encontraron estudiantes con el carnet:", carnet);
            }
        } else {
            console.log("No se encontraron estudiantes con el carnet:", carnet);
        }
    }

    public delete(carnet: string): void {
        const index: number = this.hash(carnet);
        if (this.data[index] !== null) {
            const deleted = this.data[index]!.delete(carnet);
            if (deleted) {
                if (this.data[index]!.head === null) {
                    this.data[index] = null;
                }
                console.log(`Estudiante con carnet ${carnet} eliminado.`);
            } else {
                console.log(`No se encontró el estudiante con carnet ${carnet} para eliminar.`);
            }
        } else {
            console.log(`No se encontró el estudiante con carnet ${carnet} para eliminar.`);
        }
    }

    public printEstudiantes(): void {
        for (let index = 0; index < this.data.length; index++) {
            const slot = this.data[index];
            if (slot === null) {
                console.log(`Espacio ${index}: null`);
            } else {
                console.log(`Espacio ${index}: ${slot.print()}`);
            }
        }
    }
}

const student1 = new Student("David Ixquiac", "EST1521223", "Sistemas");
const student2 = new Student("Ivan Ordoñez", "EST1614255", "Civil");
const student3 = new Student("Pablo Lopez", "EST2614213", "Medicina");
const student4 = new Student("Miguel Salguero", "EST1523156", "Derecho");

const hashTable = new HashTable();

hashTable.insert(student1);
hashTable.insert(student2);
hashTable.insert(student3);
hashTable.insert(student4);
console.log("")
console.log("Tabla:");
hashTable.printEstudiantes();
console.log("")
console.log("Buscar:");
hashTable.search("EST1521223");
console.log("")
console.log("Eliminar:");
hashTable.delete("EST1523156");
console.log("")
console.log("Tabla:");
hashTable.printEstudiantes();