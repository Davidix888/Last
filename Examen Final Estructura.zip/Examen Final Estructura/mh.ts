class Task {
    private name: string;
    private priority: number;
    private descripcion: string;

    constructor(name: string, priority: number, descripcion: string) {
        this.name = name;
        this.priority = priority;
        this.descripcion = descripcion;
    }

    public getNameTask(): string {
        return this.name;
    }

    public getPriorityTask(): number {
        return this.priority;
    }

    public getDescriptionTask(): string {
        return this.descripcion;
    }

    public setPriority(priority: number): void {
        this.priority = priority;
    }
}

class MaxHeapTask {
    public heap: Task[];
    private n: number;

    constructor(size: number) {
        this.heap = new Array(size + 1);
        this.n = 0;
    }

    public getQuantity(): number {
        return this.n;
    }

    public insert(value: Task): void {
        if (this.n === this.heap.length - 1) {
            this.resize(2 * this.heap.length);
        }
        this.n++;
        this.heap[this.n] = value;
        this.swim(this.n);
    }

    public getMax(): Task {
        let max = this.heap[1];
        this.heap[1] = this.heap[this.n];
        this.n--;
        this.sink(1);
        return max;
    }

    private swim(i: number): void {
        let parent = Math.floor(i / 2);
        while (i > 1 && this.heap[parent]!.getPriorityTask() < this.heap[i]!.getPriorityTask()) {
            [this.heap[parent], this.heap[i]] = [this.heap[i], this.heap[parent]];
            i = parent;
            parent = Math.floor(i / 2);
        }
    }

    private sink(i: number): void {
        while (2 * i <= this.n) {
            let child = 2 * i;
            if (child < this.n && this.heap[child]!.getPriorityTask() < this.heap[child + 1]!.getPriorityTask()) {
                child++;
            }
            if (this.heap[i]!.getPriorityTask() >= this.heap[child]!.getPriorityTask()) {
                break;
            }
            [this.heap[i], this.heap[child]] = [this.heap[child], this.heap[i]];
            i = child;
        }
    }

    public actualizar(taskName: string, newPriority: number): void {
        for (let i = 1; i <= this.n; i++) {
            if (this.heap[i].getNameTask() === taskName) {
                this.heap[i].setPriority(newPriority);
                this.swim(i); 
                this.sink(i);
                return;
            }
        }
        console.log(`Tarea "${taskName}" no encontrada`);
    }

    private resize(newSize: number): void {
        let newHeap: Task[] = new Array(newSize);
        for (let i = 1; i <= this.n; i++) {
            newHeap[i] = this.heap[i];
        }
        this.heap = newHeap;
    }

    public mostrartareas(): void {
        for (let i = 1; i <= this.n; i++) {
            const task = this.heap[i];
            console.log(task.getNameTask() + " - Prioridad: " + task.getPriorityTask());
        }
    }

    public buscar(name: string): Task[] {
        let buscar: Task[] = new Array(this.n);
        let contador = 0;
    
        for (let i = 1; i <= this.n; i++) {
            if (this.heap[i].getNameTask() === name) {
                buscar[contador] = this.heap[i];
                contador++;
            }
        }
    
        let busqueda: Task[] = new Array(contador);
        for (let j = 0; j < contador; j++) {
            busqueda[j] = buscar[j];
        }
    
        return busqueda;
    }
    
}

let task1: Task = new Task("Calificar Laboratorio 1", 1, "Prioridad 1");
let task2: Task = new Task("Calificar Laboratorio 2", 4, "Prioridad 4");
let task3: Task = new Task("Preparar la siguiente clase", 2, "Prioridad 2");

let maxHeap = new MaxHeapTask(6);

maxHeap.insert(task1);
maxHeap.insert(task2);
maxHeap.insert(task3);

console.log("Tareas:");
maxHeap.mostrartareas();
console.log("");

maxHeap.actualizar("Calificar Laboratorio 2", 6);

console.log("Tareas con prioridad actualizada:");
maxHeap.mostrartareas();

console.log("");
let maxTask = maxHeap.getMax();
console.log("Tarea eliminada:", maxTask.getNameTask());

console.log("");
console.log("Tareas restantes:");
maxHeap.mostrartareas();

console.log("");
console.log("Buscar tarea por prioridad:");

let buscar1 = maxHeap.buscar("Calificar Laboratorio 1");
for (let i = 0; i < buscar1.length; i++) {
    console.log(
        buscar1[i].getNameTask() +  " - Prioridad: " +  buscar1[i].getPriorityTask());
}

